FSE 2020-1 Practica 5

Caballero Montano Montserrat
De La Cruz Flores Hugo Alberto

Objetivo de la práctica:	
	Realizar un programa en C o Python que reciba de una línea de comandos nombre del archivo y un número, para crear un archivo con extensión .csv el cual se almacenará en una unidad USB.	

Desarrollo de la práctica:
* Primero se buscó la carpeta donde se montan las USB's en las raspberry
* Se creó un documento en esa dirección que contiviera la información necesaria
* Se colocó la usb y se probó el programa abriendo otro SSH para ver el contenido de la memoria.

**Se anexa archivo .csv de la práctica	