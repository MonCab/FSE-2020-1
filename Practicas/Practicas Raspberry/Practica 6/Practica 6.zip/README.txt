FSE 2020-1 Practica 6

Caballero Montano Montserrat
De La Cruz Flores Hugo Alberto

Objetivo de la práctica:	
	Utilizar la comunicación i2c utilizando un reloj de tiempo real y ver el funcionamientodel reloj de la raspberry y el anterior mencionado

Desarrollo de la práctica:
* Preparar la raspberry para que funcione con la comunicación i2c.
* Conectar el reloj de tiempo real a la raspberry.
* Configurar el reloj de tiempo real.
* Realizar el programa que leyera del reloj de la raspberry y el de tiempo real e imprimiera ambos en consola.

**Se anexa archivo .csv con la información 
	