FSE 2020-1 Proyecto Final

Caballero Montano Montserrat
De La Cruz Flores Hugo Alberto

Objetivo:	
	Demostrar la funcionalidad de Sigfox y utilizar dicha comunicación para enviar información de un sensor de temperatura al backend. 

Desarrollo del proyecto:
* Elección y compra de un módulo de Sigfox.
* Obtención de membresia para el acceso a la red de Sigfox.
* Conexión al backend. 
* Configuración y creación del código para el sensor DHT11.
* Configuración y primera comunicación con el módulo de Sigfox.
* Fusión de ambos códigos para el funcionamiento real.
* Realización de un Google Script para la visualización de los datos en una Hoja de Cálculo de Google.


**Se anexan imagenes con el backend, el script, la hoja de cálculo y la ubicación del módulo. 


Liga al video: https://youtu.be/99BSORvuyhs