import serial
import time
import sys
import Adafruit_DHT

# Configuracion del tipo de sensor DHT
sensor = Adafruit_DHT.DHT11

# Configuracion del puerto GPIO al cual esta conectado  (GPIO 23)
pin = 23

i = 0

port = serial.Serial("/dev/ttyAMA0", baudrate=9600, timeout=4.0)

# Intenta ejecutar las siguientes instrucciones, si falla va a la instruccion except
try:	
	# Ciclo principal infinito
	while i < 10:
		# Obtiene la humedad y la temperatura desde el sensor 
		humedad, temperatura = Adafruit_DHT.read_retry(sensor, pin)
		
		# Imprime en la consola las variables temperatura y humedad con un decimal
		print('Temperatura={0:0.1f}*  Humedad={1:0.1f}%'.format(temperatura, humedad))
		
		data = str(temperatura) + ":" + str(humedad)		

		port.write(data)
		rcv = port.readline()
		#port.write(repr(rcv))
		print(rcv)
		i += 1

		# Duerme 10 segundos
		time.sleep(10)

# Se ejecuta en caso de que falle alguna instruccion dentro del try
except Exception,e:
	# Imprime en pantalla el error e
	print str(e)

port.close()
