#include <stdio.h>
int i = 0;
int main(int argc, char **argv) {
	for (i = 0; i <15 ; i++){
		printf("\n\n #%i FSE2020-1 Caballero Ft De La Cruz   ",i+1);
	}
	return 0;
}
